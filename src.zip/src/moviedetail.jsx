import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
 
export default function MovieDetail(){
  const {id} =useParams();
  
  const [movie,setMovie] = useState([]);
   
  useEffect(() => {
    fetch(`https://65f17108034bdbecc7629d11.mockapi.io/user/${id}`,{
        method:"GET"
    })
    .then((data)=> data.json())
    .then((mv) =>setMovie(mv));
  },[]);
   
  console.log(movie);

  return(
    <div>
        <iframe width="656" height="369" src={movie.trailer} title={movie.name} frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
  )
}